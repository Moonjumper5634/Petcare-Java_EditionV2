package ph.gov.santarosa.petcare.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import ph.gov.santarosa.petcare.domain.Pet;

public interface PetRepository extends JpaRepository<Pet, String> {
    List<Pet> findByOwnerId(String ownerId);
    List<Pet> findByOwnerIdAndRegistrationStatus(String ownerId, String registrationStatus);
}
