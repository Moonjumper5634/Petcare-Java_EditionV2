package ph.gov.santarosa.petcare.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import ph.gov.santarosa.petcare.domain.EligibilityAssessmentCriterion;

public interface EligibilityAssessmentCriterionRepository extends JpaRepository<EligibilityAssessmentCriterion, Long> {
    List<EligibilityAssessmentCriterion> findByAssessmentIdOrderBySeq(Long assessmentId);
}
